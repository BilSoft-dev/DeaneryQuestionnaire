﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data.EntityClient;
using System.Data.Metadata.Edm;

namespace BLL
{
    public static class Queries
    {

        public static List<int> GetKurs(string academicYear)
        {
            using (DekanatEntities db = new DekanatEntities(Connection.Conn))
            {
                var result = (from g in db.Grups
                              where g.Uch_god == academicYear
                              orderby g.KURS
                              select g.KURS).Distinct();
                
                 List<int> list = new List<int>();
                 foreach (int i in result)
                     list.Add(i);
                
                return list;
            }
        }

        public static List<Grups> GetGrups(string academicYear, int kurs)
        {
            using (DekanatEntities db = new DekanatEntities(Connection.Conn))
            {
                var result = from g in db.Grups
                             where g.Uch_god == academicYear && g.KURS == kurs
                             orderby g.GRUPA
                             select g;
                return result.ToList();
            }
        }

        public static int GetGroupID(string academicYear, int kurs, int grupa)
        {
            using (DekanatEntities db = new DekanatEntities(Connection.Conn))
            {
                Grups result = (from g in db.Grups
                             where g.Uch_god == academicYear && g.KURS == kurs
                                   && g.GRUPA == grupa
                             select g).First();
                return int.Parse(result.GroupID.ToString());
            }
        }

        public static List<SpravochnikStudentov> GetStudents(int groupID)
        {
            using (DekanatEntities db = new DekanatEntities(Connection.Conn))
            {
                List<SpravochnikStudentov> result = (from stud in db.SpravochnikStudentov
                                                     where stud.Grups.GroupID == groupID
                                                     select stud).ToList();
                return result;
            }
        }

        public static SpravochnikSpeciality GetSpeciality(int GroupID)
        {
            using (DekanatEntities db = new DekanatEntities(Connection.Conn))
            {
                SpravochnikSpeciality result = (from g in db.Grups
                                                where g.GroupID == GroupID
                                                select g.SpravochnikSpecializaciy.SpravochnikSpeciality).First();
                return result;
            }
        }
    }
}