﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data.EntityClient;
using System.Data.Metadata.Edm;

namespace BLL
{
    public static class Connection
    {
        private static string model = "ModelDeanery";
        private static SqlConnectionStringBuilder sqlBuilder = new SqlConnectionStringBuilder();
        private static EntityConnectionStringBuilder entityBuilder = new EntityConnectionStringBuilder();

        public static void SetConnect(string server, string database,
            string login, string password)
        {
            // Set the properties for the data source.
            sqlBuilder.DataSource = server;
            sqlBuilder.InitialCatalog = database;
            sqlBuilder.UserID = login;
            sqlBuilder.Password = password;
            // Build the SqlConnection connection string.
            string providerString = sqlBuilder.ToString();

            //Set the provider name.
            entityBuilder.Provider = "System.Data.SqlClient";

            // Set the provider-specific connection string.
            entityBuilder.ProviderConnectionString = providerString;

            // Set the Metadata location.
            entityBuilder.Metadata = @"res://*/" + model + ".csdl|"
                            + "res://*/" + model + ".ssdl|"
                            + "res://*/" + model + ".msl";
        }

        public static string Conn
        {
            get { return entityBuilder.ToString(); }
        }
    }
}