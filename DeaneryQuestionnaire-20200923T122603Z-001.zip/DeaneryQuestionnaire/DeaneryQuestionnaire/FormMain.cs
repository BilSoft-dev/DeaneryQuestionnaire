﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using DeaneryQuestionnaire.Settings;

namespace DeaneryQuestionnaire
{
    public partial class FormMain : Form
    {
        private AboutBox about;
        private FormSettings frmSettings;
        private FormQuestionnaire frmQuestionnaire;
        private Settings.Settings obSettings = new Settings.Settings();

        public FormMain()
        {
            InitializeComponent();
            try
            {
                obSettings = Settings.IO.ReadSettings();
            }
            catch (FileNotFoundException exp)
            {
                MessageBox.Show(exp.Message, "Error !", MessageBoxButtons.OK);
            }
        }

        private void toolStripMenuItemSettings_Click(object sender, EventArgs e)
        {
            frmSettings = new FormSettings(obSettings);
            if (frmSettings.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show("Settings were saved successfully", "Successful", MessageBoxButtons.OK);
                obSettings = Settings.IO.ReadSettings();
            }
            else
                MessageBox.Show("Settings were not saved", "Settings", MessageBoxButtons.OK);
        }

        private void toolStripMenuItemExit_Click(object sender, EventArgs e)
        { Application.Exit(); }

        private void toolStripMenuItemQuestionnaire_Click(object sender, EventArgs e)
        {
            frmQuestionnaire = new FormQuestionnaire(obSettings);
            frmQuestionnaire.Show();
        }

        private void toolStripMenuItemAbout_Click(object sender, EventArgs e)
        {
            about = new AboutBox();
            about.ShowDialog(); 
        }
    }
}