﻿namespace DeaneryQuestionnaire
{
    partial class FormQuestionnaire
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelCurrentYear = new System.Windows.Forms.Label();
            this.maskedTextBoxAcademicYear = new System.Windows.Forms.MaskedTextBox();
            this.labelKurs = new System.Windows.Forms.Label();
            this.comboBoxKurs = new System.Windows.Forms.ComboBox();
            this.labelGrups = new System.Windows.Forms.Label();
            this.checkedListBoxGrups = new System.Windows.Forms.CheckedListBox();
            this.buttonFormate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelCurrentYear
            // 
            this.labelCurrentYear.AutoSize = true;
            this.labelCurrentYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelCurrentYear.Location = new System.Drawing.Point(12, 37);
            this.labelCurrentYear.Name = "labelCurrentYear";
            this.labelCurrentYear.Size = new System.Drawing.Size(99, 16);
            this.labelCurrentYear.TabIndex = 1;
            this.labelCurrentYear.Text = "Academic year";
            // 
            // maskedTextBoxAcademicYear
            // 
            this.maskedTextBoxAcademicYear.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.maskedTextBoxAcademicYear.Location = new System.Drawing.Point(120, 31);
            this.maskedTextBoxAcademicYear.Mask = "0000-00";
            this.maskedTextBoxAcademicYear.Name = "maskedTextBoxAcademicYear";
            this.maskedTextBoxAcademicYear.Size = new System.Drawing.Size(100, 27);
            this.maskedTextBoxAcademicYear.TabIndex = 2;
            this.maskedTextBoxAcademicYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelKurs
            // 
            this.labelKurs.AutoSize = true;
            this.labelKurs.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelKurs.Location = new System.Drawing.Point(12, 70);
            this.labelKurs.Name = "labelKurs";
            this.labelKurs.Size = new System.Drawing.Size(34, 16);
            this.labelKurs.TabIndex = 3;
            this.labelKurs.Text = "Kurs";
            // 
            // comboBoxKurs
            // 
            this.comboBoxKurs.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxKurs.FormattingEnabled = true;
            this.comboBoxKurs.Location = new System.Drawing.Point(120, 64);
            this.comboBoxKurs.Name = "comboBoxKurs";
            this.comboBoxKurs.Size = new System.Drawing.Size(100, 27);
            this.comboBoxKurs.TabIndex = 4;
            this.comboBoxKurs.SelectionChangeCommitted += new System.EventHandler(this.comboBoxKurs_SelectionChangeCommitted);
            // 
            // labelGrups
            // 
            this.labelGrups.AutoSize = true;
            this.labelGrups.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelGrups.Location = new System.Drawing.Point(223, 12);
            this.labelGrups.Name = "labelGrups";
            this.labelGrups.Size = new System.Drawing.Size(47, 16);
            this.labelGrups.TabIndex = 5;
            this.labelGrups.Text = "Grups:";
            // 
            // checkedListBoxGrups
            // 
            this.checkedListBoxGrups.FormattingEnabled = true;
            this.checkedListBoxGrups.Location = new System.Drawing.Point(226, 31);
            this.checkedListBoxGrups.Name = "checkedListBoxGrups";
            this.checkedListBoxGrups.Size = new System.Drawing.Size(74, 169);
            this.checkedListBoxGrups.TabIndex = 6;
            // 
            // buttonFormate
            // 
            this.buttonFormate.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonFormate.Location = new System.Drawing.Point(12, 166);
            this.buttonFormate.Name = "buttonFormate";
            this.buttonFormate.Size = new System.Drawing.Size(208, 34);
            this.buttonFormate.TabIndex = 7;
            this.buttonFormate.Text = "Formate";
            this.buttonFormate.UseVisualStyleBackColor = true;
            this.buttonFormate.Click += new System.EventHandler(this.buttonFormate_Click);
            // 
            // FormQuestionnaire
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(310, 207);
            this.Controls.Add(this.buttonFormate);
            this.Controls.Add(this.checkedListBoxGrups);
            this.Controls.Add(this.labelGrups);
            this.Controls.Add(this.comboBoxKurs);
            this.Controls.Add(this.labelKurs);
            this.Controls.Add(this.maskedTextBoxAcademicYear);
            this.Controls.Add(this.labelCurrentYear);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormQuestionnaire";
            this.Text = "Questionnaire";
            this.Load += new System.EventHandler(this.FormQuestionnaire_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelCurrentYear;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxAcademicYear;
        private System.Windows.Forms.Label labelKurs;
        private System.Windows.Forms.ComboBox comboBoxKurs;
        private System.Windows.Forms.Label labelGrups;
        private System.Windows.Forms.CheckedListBox checkedListBoxGrups;
        private System.Windows.Forms.Button buttonFormate;
    }
}