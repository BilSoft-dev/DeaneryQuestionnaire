﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DeaneryQuestionnaire.Questionnaire
{
    public static class Formats
    {
        private const int cell_length = 45;

        public static int CELL_LENGTH
        {
            get { return cell_length; }
        }
    }
}