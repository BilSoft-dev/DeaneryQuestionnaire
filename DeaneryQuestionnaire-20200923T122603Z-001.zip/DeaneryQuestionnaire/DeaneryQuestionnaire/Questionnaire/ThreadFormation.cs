﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BLL;
using DeaneryQuestionnaire.PB;
using DeaneryQuestionnaire.Questionnaire;

namespace DeaneryQuestionnaire.Questionnaire
{
    public class ThreadFormation
    {
        private WorkProgressBar obPB;
        private CheckedListBox cLB;
        private string academicYear;
        private string kurs;
        private string path;

        public ThreadFormation(string academicYear, string kurs,
            CheckedListBox cLB, string path, WorkProgressBar obPB)
        {
            this.academicYear = academicYear;
            this.kurs = kurs;
            this.cLB = cLB;
            this.path = path;
            this.obPB = obPB;
        }

        public void Formate()
        {
            try
            {
                for (int i = 0; i < cLB.Items.Count; i++)
                {
                    if (cLB.GetItemChecked(i))
                    {
                        int ID = Queries.GetGroupID(academicYear,
                            int.Parse(kurs),
                            int.Parse(cLB.Items[i].ToString()));
                        List<SpravochnikStudentov> lstStudents = Queries.GetStudents(ID);
                        SpravochnikSpeciality obSpeciality = Queries.GetSpeciality(ID);
                        string kursgrupa = kurs + "-" + cLB.Items[i].ToString();

                        QuestionnaireExcel obQExcel = new QuestionnaireExcel();
                        obQExcel.FormateQuestionnaire(
                            lstStudents,
                            obSpeciality,
                            academicYear,
                            kursgrupa,
                            path);
                    }
                    obPB.IncreaseValueProgress();
                }
                MessageBox.Show("Questionnaires were been formated", "Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception exp)
            { MessageBox.Show(exp.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            finally
            { obPB.CloseProgress(); }
        }

    }
}