﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using System.Data.Objects;
using BLL;
using Excel = Microsoft.Office.Interop.Excel;

namespace DeaneryQuestionnaire.Questionnaire
{
    public class QuestionnaireExcel
    {
        private Excel.Application xlApp;
        private Excel.Worksheet xlWorkSheet;
        private System.Globalization.CultureInfo oldCI;

        public QuestionnaireExcel()
        { xlApp = new Microsoft.Office.Interop.Excel.Application(); }

        public void FormateQuestionnaire(List<SpravochnikStudentov> lstStudents,
            SpravochnikSpeciality obSpeciality, string academicYear, string kusrgrupa,string path)
        {
            path += "\\" + academicYear;
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);

            path += "\\" + kusrgrupa;
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);

            foreach (SpravochnikStudentov obStudent in lstStudents)
            {
                string newpath = copy(path, obStudent.FAMILIYA.ToString() + " " + obStudent.NAME.ToString());
                formate(newpath, obStudent, obSpeciality);
            }
        }

        private string copy(string path_questionnaire, string filename)
        {
            FileInfo file = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\Templates\Q.xls");
            string newfile = path_questionnaire + "\\" + filename + ".xls";
            file.CopyTo(newfile, true);
            return newfile;
        }

        private void formate(string path_filename, 
            SpravochnikStudentov obStudent, SpravochnikSpeciality obSpeciality)
        {
            oldCI = System.Threading.Thread.CurrentThread.CurrentCulture;
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("ru-RU");

            xlApp.Workbooks.Open(path_filename, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            xlWorkSheet = (Excel.Worksheet)xlApp.Worksheets[1];

            xlWorkSheet.Cells["13", "D"] = "X";
            if (obStudent.PASPORT.ToString() != "")
            {
                xlWorkSheet.Cells["15", "C"] = obStudent.PASPORT.ToString().Substring(0, 2);
                xlWorkSheet.Cells["15", "G"] = obStudent.PASPORT.ToString().Substring(2);
            }

            if (obStudent.POL.ToString() == "м") xlWorkSheet.Cells["17", "D"] = "X";
            else xlWorkSheet.Cells["17", "G"] = "X";

            if (obStudent.BORN_DATE.ToString() != "")
                xlWorkSheet.Cells["19", "D"] = ((DateTime)obStudent.BORN_DATE).ToShortDateString();
            xlWorkSheet.Cells["21", "C"] = obStudent.FAMILIYA.ToString();
            xlWorkSheet.Cells["23", "C"] = obStudent.NAME.ToString();
            xlWorkSheet.Cells["25", "C"] = obStudent.OTCHESTVO.ToString();
            if (obStudent.IDENTIF_KOD.ToString() != "") 
                xlWorkSheet.Cells["27", "D"] = obStudent.IDENTIF_KOD.ToString();

            char shifr = obSpeciality.SHIFR_SPECIALITY.ToString()[0];
            switch (shifr)
            {
                case '6':
                    {
                        xlWorkSheet.Cells["34", "B"] = "X";
                        xlWorkSheet.Cells["40", "D"] = obSpeciality.NAME_SPECIALITY.ToString();
                    } break;
                case '7':
                    {
                        xlWorkSheet.Cells["36", "B"] = "X";

                        string temp = obSpeciality.NAME_SPECIALITY.ToString();
                        if (temp.Length <= Formats.CELL_LENGTH) temp += "\n";
                        xlWorkSheet.Cells["42", "D"] = temp;
                    } break;
                case '8':
                    {
                        xlWorkSheet.Cells["38", "B"] = "X";

                        string temp = obSpeciality.NAME_SPECIALITY.ToString();
                        if (temp.Length <= Formats.CELL_LENGTH) temp += "\n";
                        xlWorkSheet.Cells["42", "D"] = temp;
                    } break;
                default: break;
            }
            string kvalification = obSpeciality.KVALIFICATION.ToString();
            if (kvalification.Length <= Formats.CELL_LENGTH) kvalification += "\n";
            xlWorkSheet.Cells["44", "D"] = kvalification;

            if ((int)obStudent.KONTRAKT == 1) xlWorkSheet.Cells["50", "B"] = "X";
            else xlWorkSheet.Cells["48", "B"] = "X";

            xlApp.Workbooks[1].Save();
            xlApp.Workbooks.Close();
        }
    }
}