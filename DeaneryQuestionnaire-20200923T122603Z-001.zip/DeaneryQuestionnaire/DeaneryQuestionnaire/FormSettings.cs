﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using DeaneryQuestionnaire.Settings;

namespace DeaneryQuestionnaire
{
    public partial class FormSettings : Form
    {
        private Settings.Settings obSettings;

        public FormSettings(Settings.Settings obSettings)
        {
            InitializeComponent();

            this.obSettings = obSettings;
            textBoxServer.Text = this.obSettings.Server;
            textBoxDatabase.Text = this.obSettings.Database;
            textBoxLogin.Text = this.obSettings.Login;
            textBoxPassword.Text = this.obSettings.Password;
            textBoxPath.Text = this.obSettings.Path;
        }

        private void buttonBrowseFolder_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                textBoxPath.Text = folderBrowserDialog.SelectedPath;
            }
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            obSettings.Server = textBoxServer.Text;
            obSettings.Database = textBoxDatabase.Text;
            obSettings.Login = textBoxLogin.Text;
            obSettings.Password = textBoxPassword.Text;
            obSettings.Path = textBoxPath.Text;
            Settings.IO.WriteSettings(obSettings);
            this.DialogResult = DialogResult.OK;
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}