﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DeaneryQuestionnaire.PB
{
    public delegate void ProgressBarDelegate();

    public class WorkProgressBar
    {
        private ProgressBarDelegate dlg;
        private FormProgressBar frmPB;

        public WorkProgressBar(string captain, int stages)
        {
            frmPB = new FormProgressBar(captain, stages);
            frmPB.Show();
            dlg = new ProgressBarDelegate(Increase);
        }

        public void IncreaseValueProgress()
        { frmPB.Invoke(dlg); }

        private void Increase()
        { frmPB.Increase(); }

        public void CloseProgress()
        {
            dlg = new ProgressBarDelegate(Close);
            frmPB.Invoke(dlg);
        }

        private void Close()
        { frmPB.Close(); }
    }
}