﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DeaneryQuestionnaire.Settings
{
    [Serializable]
    public class Settings
    {
        private string server;
        private string database;
        private string login;
        private string password;
        private string path;

        public string Server
        {
            set { server = value; }
            get { return server; }
        }

        public string Database
        {
            set { database = value; }
            get { return database; }
        }

        public string Login
        {
            set { login = value; }
            get { return login; }
        }

        public string Password
        {
            set { password = value; }
            get { return password; }
        }

        public string Path
        {
            set { path = value; }
            get { return path; }
        }
    }
}