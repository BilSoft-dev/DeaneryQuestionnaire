﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace DeaneryQuestionnaire.Settings
{
    static public class IO
    {
        public static void WriteSettings(Settings ob)
        {
            DirectoryInfo dinfo = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
            String filename = "Settings.dat";

            bool exist = false;
            foreach (FileInfo file in dinfo.GetFiles())
            {

                if (file.Name == filename)
                {
                    exist = true;
                }
            }
            if (!exist)
            {
                FileStream filestream = new FileStream(filename, FileMode.CreateNew);
                filestream.Close();
            }

            BinaryFormatter formatter = new BinaryFormatter();
            FileStream fs = new FileStream(filename, FileMode.Create);
            formatter.Serialize(fs, ob);
            fs.Close();
        }

        public static Settings ReadSettings()
        {
            Settings ob;
            String filename = "Settings.dat";
            FileStream fs = null;

            if ((fs = new FileStream(filename, FileMode.Open)) != null)
            {
                BinaryFormatter formatter = new BinaryFormatter();
                ob = (Settings) formatter.Deserialize(fs);
                return ob;
            }
            else throw new FileNotFoundException("File is absent !");
        }
    }
}