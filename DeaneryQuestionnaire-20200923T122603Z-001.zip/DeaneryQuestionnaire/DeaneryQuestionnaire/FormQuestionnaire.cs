﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using BLL;
using DeaneryQuestionnaire.Questionnaire;

namespace DeaneryQuestionnaire
{
    public partial class FormQuestionnaire : Form
    {
        private Settings.Settings obSettings;

        public FormQuestionnaire(Settings.Settings obSettings)
        {
            InitializeComponent();
            this.obSettings = obSettings;

            Connection.SetConnect(obSettings.Server, obSettings.Database,
                obSettings.Login, obSettings.Password);

            int year = DateTime.Now.Year;
            string academicYear = (year-1).ToString() + "-" + year.ToString().Substring(2);
            maskedTextBoxAcademicYear.Text = academicYear;

            List<int> grups = Queries.GetKurs(academicYear);
            foreach (int ob in grups)
            {
                comboBoxKurs.Items.Add(ob.ToString());
            }
        }

        private void FormQuestionnaire_Load(object sender, EventArgs e)
        {
            if (comboBoxKurs.Items.Count > 0)
            {
                comboBoxKurs.SelectedIndex = 0;
                comboBoxKurs_SelectionChangeCommitted(sender, e);
            }
            else buttonFormate.Enabled = false;
        }

        private void comboBoxKurs_SelectionChangeCommitted(object sender, EventArgs e)
        {
            checkedListBoxGrups.Items.Clear();
            List<Grups> grups = Queries.GetGrups(maskedTextBoxAcademicYear.Text,
                int.Parse(comboBoxKurs.SelectedItem.ToString()));

            foreach (Grups ob in grups)
                checkedListBoxGrups.Items.Add(ob.GRUPA, CheckState.Checked);
        }

        private void buttonFormate_Click(object sender, EventArgs e)
        {
            PB.WorkProgressBar obPB = new DeaneryQuestionnaire.PB.WorkProgressBar(
                "Formation questionnaires for " + comboBoxKurs.SelectedItem.ToString() + " kurs",
                checkedListBoxGrups.Items.Count);

            ThreadFormation pfTF = new ThreadFormation(
                maskedTextBoxAcademicYear.Text,
                comboBoxKurs.SelectedItem.ToString(),
                checkedListBoxGrups,
                obSettings.Path,
                obPB);

            Thread t = new Thread(new ThreadStart(pfTF.Formate));
            t.Start();
        }
    }
}